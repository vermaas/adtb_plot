"""
    File name: atdb_plot.py
    version: 1.0.0 (28 mar 2019)
    Author: Copyright (C) 2019 - Nico Vermaas - ASTRON
    Description: atdb plot module
"""

import plotly
import plotly.graph_objs as go


# --- plot functions  ---

def do_electricity_plots(title, xx,yy, legends, type, output_html,y_axis_title='verbruik'):
    """
    :param title: Title of Plot
    :param x: dict with data for x-axis (time)
    :param y: dict with data for y_axix (usage)
    :return:
    """
    print('do_electricity_plots()')

    line_consumption = go.Scatter(
        x=xx[0],
        y=yy[0],
        mode='lines',
        name=legends[0]
    )
    line_redelivery = go.Scatter(
        x=xx[1],
        y=yy[1],
        mode='lines',
        name = legends[1]
    )
    bar_totals = go.Bar(
        x=xx[2],
        y=yy[2],
        marker=dict(
            color='rgb(255,221,0)',
        ),
        name=legends[2]
    )

    layout = go.Layout(
        title=title,
        xaxis=dict(tickangle=-45),
        plot_bgcolor='rgb(230,230,230)',
        yaxis = dict(
            title=y_axis_title,
            titlefont=dict(
            family='Courier New, monospace',
            size=18,
            color='#7f7f7f'),
        ),
        barmode = 'group',

    )

    data = [bar_totals,line_consumption,line_redelivery]

    fig = go.Figure(data=data, layout=layout)
    plotly.offline.plot(fig,filename=output_html)


def do_plot(title, x,y, type, output_html,y_axis_title='y-axis'):
    """

    :param title: Title of Plot
    :param x: dict with data for x-axis (time)
    :param y: dict with data for y_axix (usage)
    :return:
    """
    print('do_plot()')

    if type == 'bar':
        trace = go.Bar(
            x=x,
            y=y,
            marker=dict(
                color='rgb(0,129,201)',
            ),
        )
        layout = go.Layout(
            title = title,
            xaxis=dict(
                tickangle=-45,
                #tickvals=x
            ),
            yaxis=dict(
                title=y_axis_title,
                titlefont=dict(
                    family='Courier New, monospace',
                    size=18,
                    color='#7f7f7f'),
            ),

            barmode='group',
            plot_bgcolor='rgb(230,230,230)'
        )

    elif type == 'scatter':
        trace = go.Scatter(
            x=x,
            y=y,
            mode='lines')
        layout = go.Layout(
            title=title,
            xaxis=dict(tickangle=-45),
            plot_bgcolor='rgb(230,230,230)'
        )

    data = [trace]

    fig = go.Figure(data=data, layout=layout)
    plotly.offline.plot(fig,filename=output_html)


# https://plot.ly/python/line-and-scatter/
def do_sky_plot(title, x,y, duration, output_html,y_axis_title='y-axis'):
    """
    :param title: Title of Plot
    :param x: dict with data for x-axis (time)
    :param y: dict with data for y_axis (usage)
    :return:
    """

    print('do_sky_plot()')

    trace = go.Scatter(
        x=x,
        y=y,
        mode='markers',
        marker = dict(
            size = 10,
            color = duration,
            colorscale='Viridis',
            showscale=True
        ),

    )
    layout = go.Layout(
        title=title,
        xaxis=dict(tickangle=0),
        plot_bgcolor='rgb(150,150,150)'
    )

    data = [trace]

    fig = go.Figure(data=data, layout=layout)
    plotly.offline.plot(fig,filename=output_html)