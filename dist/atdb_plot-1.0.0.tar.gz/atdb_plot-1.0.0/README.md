# atdb_plot
This is a atdb prototype utililty to visualise statistics from ATDB.
- It can use mathplotlib or plotly to make plots.
- It can access the ATDB REST API or the ATDB database directly (not recommended)

## current presentations
- sky view
- ingest sizes imaging/arts
- observing/ingest speeds
